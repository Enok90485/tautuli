# Tautulli

A python based web application for monitoring, analytics and notifications for 
[Plex Media Server](https://plex.tv).

This project is based on code from [Headphones](https://github.com/rembo10/headphones)
and [PlexWatchWeb](https://github.com/ecleese/plexWatchWeb).

## Features

-   Responsive web design viewable on desktop, tablet and mobile web browsers.
-   Themed to complement Plex/Web.
-   Easy configuration setup (no separate web server required).
-   Monitor current Plex Media Server activity.
-   Fully customizable notifications for stream activity and recently added media.
-   Top statistics on home page with configurable duration and measurement metric.
-   Global watching history with search/filtering & dynamic column sorting.
-   Full user list with general information and comparison stats.
-   Individual user information including devices IP addresses.
-   Complete library statistics and media file information.
-   Rich analytics presented using Highcharts graphing.
-   Beautiful content information pages.
-   Full sync list data on all users syncing items from your library.
-   And many more!!

## Preview

[Full preview gallery available on our website][Tautulli]

![Tautulli Homepage](https://tautulli.com/images/screenshots/activity-compressed.jpg?v=2)

## Installation

[![Python][badge-python]][Python]
[![Docker Pulls][badge-docker-pulls]][DockerHub]
[![Docker Stars][badge-docker-stars]][DockerHub]
[![Downloads][badge-downloads]][Releases Latest]

[badge-python]: https://img.shields.io/badge/python->=3.11-blue?style=flat-square
[badge-docker-pulls]: https://img.shields.io/docker/pulls/tautulli/tautulli?style=flat-square
[badge-docker-stars]: https://img.shields.io/docker/stars/tautulli/tautulli?style=flat-square
[badge-downloads]: https://img.shields.io/github/downloads/Tautulli/Tautulli/total?style=flat-square

| Status | Branch: `master` | Branch: `beta` | Branch: `nightly` |
| --- | --- | --- | --- |
| Release   | [![Release@master][badge-release-master]][Releases Latest] <br> [![Release Date@master][badge-release-master-date]][Releases Latest] | [![Release@beta][badge-release-beta]][Releases] <br> [![Commits@beta][badge-release-beta-commits]][Commits Beta] | [![Last Commits@nightly][badge-release-nightly-last-commit]][commits Nightly] <br> [![Commits@nightly][badge-release-nightly-commits]][Commits Nightly] |

Read the [Installation Guides][Installation] for instructions on how to install Tautulli.

[badge-release-master]: https://img.shields.io/github/v/release/Tautulli/Tautulli?style=flat-square
[badge-release-master-date]: https://img.shields.io/github/release-date/Tautulli/Tautulli?style=flat-square&color=blue
[badge-release-beta]: https://img.shields.io/github/v/release/Tautulli/Tautulli?include_prereleases&style=flat-square
[badge-release-beta-commits]: https://img.shields.io/github/commits-since/Tautulli/Tautulli/latest/beta?style=flat-square&color=blue
[badge-release-nightly-last-commit]: https://img.shields.io/github/last-commit/Tautulli/Tautulli/nightly?style=flat-square&color=blue
[badge-release-nightly-commits]: https://img.shields.io/github/commits-since/Tautulli/Tautulli/latest/nightly?style=flat-square&color=blue

## Support

[![Wiki][badge-wiki]][Wiki]
[![Discord][badge-discord]][Discord]
[![Reddit][badge-reddit]][Reddit]
[![Issues][badge-issues]][Issues]

[badge-wiki]: https://img.shields.io/badge/github-wiki-black?style=flat-square
[badge-discord]: https://img.shields.io/discord/183396325142822912?label=discord&style=flat-square&color=7289DA
[badge-reddit]: https://img.shields.io/reddit/subreddit-subscribers/tautulli?label=reddit&style=flat-square&color=FF5700
[badge-issues]: https://img.shields.io/badge/github-issues-black?style=flat-square

If you think you've found a bug in Tautulli make sure you have read the [FAQ][]
first to make sure it hasn't been covered by one of the questions there. If your
problem isn't answered in the FAQ try the following first:

-   Update to the latest version of Tautulli.
-   Turning your device off and on again.
-   Analyzing your logs, you just might find the solution yourself!
-   Using the **search** function to see if this issue has already been reported/solved.
-   Checking the [Wiki][] for [Installation][] instructions and reading the [FAQs][FAQ].
-   For basic questions try asking on [Discord][] first before opening an issue.

**If nothing has worked:**

1.  Please check the [issues tracker][Issues] to see if someone else has already reported the bug.
2.  If this is a new bug, open a [bug report][Issue New] on the issues tracker.
3.  Provide a clear title to easily help identify your problem.
4.  Use proper [Markdown syntax][] to structure your post (i.e. code/log in code blocks).
5.  Make sure to fill out the required information on the issue template.
6.  Close your issue when it's solved! If you found the solution yourself please
    comment so that others benefit from it.

## Feature Requests

1.  Pleases check the [issues tracker][Issues] to see if someone else has already requested the feature.
    If a similar idea has already been requested, _give it a thumbs up_. **Do not comment
    with `+1` or something similar as it creates unnecessary spam.**
2.  If this is a new feature request, open a [feature request][Issue New] on the issues tracker.

## License

[![License][badge-license]][License]

[badge-license]: https://img.shields.io/github/license/Tautulli/Tautulli?style=flat-square

This is free software under the GPL v3 open source license. Feel free to do with it what you wish,
but any modification must be open sourced. A copy of the license is included.

This software includes Highsoft software libraries which you may freely distribute for 
non-commercial use. Commercial users must licence this software, for more information visit
https://shop.highsoft.com/faq/non-commercial#non-commercial-redistribution.

## AI Disclosure (August 10, 2026)

### How AI Tools Are Being Used:
- Provide some context alongside an error message to better understand the source of the issue.
- Create a plan for implementing new features.
- Execute initial implementation/changes for features.
- Ask to review code to look for issues or inefficiencies and provide recommendations.
- All AI responses are thoroughly reviewed and verified by a human before being used in the codebase.

### How AI Tools Are _Not_ Being Used:
- No AI code has been used without thorough review.
- No AI media generation of any kind.

[Python]: https://python.org/downloads
[DockerHub]: https://hub.docker.com/r/tautulli/tautulli
[Releases]: https://github.com/Tautulli/Tautulli/releases
[Releases Latest]: https://github.com/Tautulli/Tautulli/releases/latest
[License]: https://github.com/Tautulli/Tautulli/blob/master/LICENSE
[FAQ]: https://github.com/Tautulli/Tautulli/wiki/Frequently-Asked-Questions
[Installation]: https://github.com/Tautulli/Tautulli/wiki/Installation
[Issues]: https://github.com/Tautulli/Tautulli/issues
[Issue New]: https://github.com/Tautulli/Tautulli/issues/new/choose
[Markdown syntax]: https://help.github.com/articles/github-flavored-markdown
[Tautulli]: http://tautulli.com
[Wiki]: https://github.com/Tautulli/Tautulli/wiki
[Discord]: https://tautulli.com/discord
[Reddit]: https://reddit.com/r/Tautulli
[Snapcraft]: https://snapcraft.io/tautulli
[Commits Beta]: https://github.com/Tautulli/Tautulli/commits/beta
[Commits Nightly]: https://github.com/Tautulli/Tautulli/commits/nightly
